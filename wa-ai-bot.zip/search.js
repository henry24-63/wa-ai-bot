// Web search - Tavily API (free tier hai). Key: !setkey tavily tvly-xxxx
export async function webSearch(cfg, query) {
  const key = cfg.keys.tavily;
  if (!key) return { text: 'Web search ki key set nahi hai.', urls: [] };
  if (!query.trim()) return { text: 'Khali search query.', urls: [] };

  const res = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({ query, max_results: 5, search_depth: 'basic', include_answer: true }),
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error(`search HTTP ${res.status} ${(await res.text()).slice(0, 100)}`);

  const d = await res.json();
  const lines = [];
  if (d.answer) lines.push(`Summary: ${d.answer}`);
  const urls = [];
  for (const r of d.results || []) {
    lines.push(`- ${r.title} (${r.url}): ${String(r.content || '').slice(0, 500)}`);
    if (r.url) urls.push(r.url);
  }
  return { text: lines.join('\n') || 'Koi result nahi mila.', urls };
}
