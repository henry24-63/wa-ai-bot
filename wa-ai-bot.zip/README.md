# WhatsApp AI Study Bot (Baileys + Groq / OpenRouter / Google AI Studio)

Sirf selected numbers ko jawab deta hai. Documents (PDF, DOCX, TXT) aur images scan/read kar sakta hai. API keys WhatsApp se hi set hoti hain.

**Is bot ke liye Oracle ka koi inbound port kholna zaroori nahi** - ye sirf bahar (outbound) connect karta hai.

## 1. Server tayyari (1 GB RAM ke liye swap zaroori)

```bash
sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab

sudo apt update && sudo apt install -y curl git ca-certificates gnupg unzip
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm i -g pm2
```

(`git` zaroori hai, Baileys ki ek dependency git se aati hai.)

## 2. Project upload aur install

PC se:
```bash
scp -i ssh-key-2026-10-29.key wa-ai-bot.zip ubuntu@<SERVER_IP>:~
```
Server par:
```bash
mkdir wa-bot && cd wa-bot && unzip ../wa-ai-bot.zip
npm install
```

## 3. WhatsApp connect (pehli baar)

Pairing code (SSH par QR se aasaan):
```bash
PAIR_PHONE=923001234567 node index.js
```
Terminal mein 8 character ka code aayega. WhatsApp > Linked devices > Link a device > **Link with phone number instead** mein code daalo.

Ya QR: `node index.js` chalao, terminal ka QR scan karo.

"Connected" aa jaye to `Ctrl+C` karo.

## 4. Hamesha chalane ke liye

```bash
pm2 start index.js --name wa-bot
pm2 save
pm2 startup      # jo command de wo copy-paste karke chalao
pm2 logs wa-bot  # logs
```

## 5. WhatsApp se setup (apni "Message yourself" chat mein)

```
!setkey groq gsk_xxx
!setkey openrouter sk-or-xxx
!setkey google AIza_xxx
!allow 923001234567
!status
```
Key bhejne ke baad bot wo message delete karne ki koshish karta hai.
`!help` se saari commands dekho. Jis ne allowed na hote hue msg kiya ho wo `!pending` mein dikhega, wahan se `!allow <id>` kar do.

## Kaise kaam karta hai

- Order: `!order groq,openrouter,google`. Pehla fail ho (limit/error) to agla try hota hai.
- Document bhejo (PDF/DOCX/TXT): text nikal kar yaad rakhta hai, phir us ke sawal pooch sakte ho. `!clear` se saaf.
- Scanned PDF: pages ki photo bhejo, vision model scan karega.
- Image: caption mein sawal likho, warna samjha deta hai.

## Dhyan rakhein

- Models ke naam badalte rehte hain. Agar error aaye to `!setmodel groq text <naya-model>`.
- Baileys unofficial hai. Apne main number par ban ka kuch risk hota hai; behtar hai alag number (spare SIM / WhatsApp Business) use karo.
- `data/` folder mein WhatsApp session aur API keys hain. Isay kisi ke saath share mat karo.
