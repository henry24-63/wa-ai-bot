// Groq, OpenRouter aur Google AI Studio - teeno OpenAI-compatible endpoint use karte hain.
// Order mein try karta hai; ek fail ho (limit, error, timeout) to agla.
// Web search: model khud "web_search" tool call karta hai jab zarurat ho.
// forceSearch=true ho (user ne khud "search karo" kaha) to pehli baar search lazmi hoti hai.
import { webSearch } from './search.js';

const ENDPOINTS = {
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions',
  google: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
};

const SEARCH_TOOL = {
  type: 'function',
  function: {
    name: 'web_search',
    description:
      'Internet search. Current/recent maloomat ke liye (news, prices, scores, naye releases, aaj ki cheezein), jab jawab pakka pata na ho, ya jab user khud search karne ko kahe. Concepts, math aur purani maloomat ke liye use mat karo.',
    parameters: {
      type: 'object',
      properties: { query: { type: 'string', description: 'Chhoti search query, behtar hai English mein' } },
      required: ['query'],
    },
  },
};

async function chat(p, key, model, messages, tools, toolChoice) {
  const body = { model, messages, temperature: 0.6, max_tokens: 4096 };
  if (tools) {
    body.tools = tools;
    body.tool_choice = toolChoice || 'auto';
  }
  const res = await fetch(ENDPOINTS[p], {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(60000),
  });
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 120)}`);
    err.status = res.status;
    throw err;
  }
  return (await res.json()).choices?.[0]?.message;
}

// Ek provider par jawab; zarurat ho to 2 baar tak search karwata hai.
async function run(cfg, p, key, model, messages, attempt, sources) {
  const msgs = [...messages];
  const tools = attempt.search ? [SEARCH_TOOL] : undefined;
  for (let round = 0; round < 3; round++) {
    const withTools = tools && round < 2;
    const choice = withTools && round === 0 && attempt.force ? 'required' : 'auto';
    const msg = await chat(p, key, model, msgs, withTools ? tools : undefined, choice);
    if (withTools && msg?.tool_calls?.length) {
      msgs.push({ role: 'assistant', content: msg.content || '', tool_calls: msg.tool_calls });
      for (const tc of msg.tool_calls) {
        let out;
        try {
          const args = JSON.parse(tc.function?.arguments || '{}');
          const r = await webSearch(cfg, String(args.query || ''));
          out = r.text;
          sources.push(...r.urls);
        } catch (e) {
          out = `Search nahi ho saki: ${e.message}`;
        }
        msgs.push({ role: 'tool', tool_call_id: tc.id, content: out });
      }
      continue;
    }
    return (msg?.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim() || null;
  }
  return null;
}

export async function askAI(cfg, messages, { vision = false, forceSearch = false } = {}) {
  const errors = [];
  const searchOn = Boolean(cfg.search && cfg.keys.tavily && !vision);
  // pehle (zaroorat ho to) lazmi search, phir normal search, aakhir mein bina search
  const attempts = !searchOn
    ? [{ search: false }]
    : forceSearch
      ? [{ search: true, force: true }, { search: true, force: false }, { search: false }]
      : [{ search: true, force: false }, { search: false }];

  for (const p of cfg.order) {
    const key = cfg.keys[p];
    const model = cfg.models[p]?.[vision ? 'vision' : 'text'];
    if (!key || !model || !ENDPOINTS[p]) continue;
    for (const attempt of attempts) {
      const sources = [];
      try {
        const text = await run(cfg, p, key, model, messages, attempt, sources);
        if (text) return { text, provider: p, model, sources: [...new Set(sources)].slice(0, 3) };
        errors.push(`${p}: khali jawab`);
        break;
      } catch (e) {
        errors.push(`${p}: ${e.message}`);
        // is model par tools/required support nahi - isi provider par agla tareeqa
        if (attempt.search && [400, 404, 422].includes(e.status)) continue;
        break;
      }
    }
  }
  throw new Error(errors.length ? errors.join(' | ') : 'Koi API key set nahi hai. Use: !setkey groq <key>');
}
