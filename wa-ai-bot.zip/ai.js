// Groq, OpenRouter aur Google AI Studio - teeno OpenAI-compatible endpoint use karte hain.
// Order mein try karta hai; ek fail ho (limit, error, timeout) to agla.
// Web search: model khud "web_search" tool call karta hai jab zarurat ho.
// forceSearch=true ho (user ne khud "search karo" kaha) to pehli baar search lazmi hoti hai.
import zlib from 'node:zlib';
import { webSearch } from './search.js';

const ENDPOINTS = {
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions',
  google: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
};

const SEARCH_TOOL = {
  type: 'function',
  function: {
    name: 'web_search',
    description:
      'Internet search. Current/recent maloomat ke liye (news, prices, scores, naye releases, aaj ki cheezein), jab jawab pakka pata na ho, ya jab user khud search karne ko kahe. Concepts, math aur purani maloomat ke liye use mat karo.',
    parameters: {
      type: 'object',
      properties: { query: { type: 'string', description: 'Chhoti search query, behtar hai English mein' } },
      required: ['query'],
    },
  },
};

async function chat(p, key, model, messages, tools, toolChoice, maxTokens = 4096) {
  const body = { model, messages, temperature: 0.6, max_tokens: maxTokens };
  if (tools) {
    body.tools = tools;
    body.tool_choice = toolChoice || 'auto';
  }
  const res = await fetch(ENDPOINTS[p], {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(60000),
  });
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 120)}`);
    err.status = res.status;
    throw err;
  }
  return (await res.json()).choices?.[0]?.message;
}

// Ek provider par jawab; zarurat ho to 2 baar tak search karwata hai.
async function run(cfg, p, key, model, messages, attempt, sources) {
  const msgs = [...messages];
  const tools = attempt.search ? [SEARCH_TOOL] : undefined;
  for (let round = 0; round < 3; round++) {
    const withTools = tools && round < 2;
    const choice = withTools && round === 0 && attempt.force ? 'required' : 'auto';
    const msg = await chat(p, key, model, msgs, withTools ? tools : undefined, choice);
    if (withTools && msg?.tool_calls?.length) {
      msgs.push({ role: 'assistant', content: msg.content || '', tool_calls: msg.tool_calls });
      for (const tc of msg.tool_calls) {
        let out;
        try {
          const args = JSON.parse(tc.function?.arguments || '{}');
          const r = await webSearch(cfg, String(args.query || ''));
          out = r.text;
          sources.push(...r.urls);
        } catch (e) {
          out = `Search nahi ho saki: ${e.message}`;
        }
        msgs.push({ role: 'tool', tool_call_id: tc.id, content: out });
      }
      continue;
    }
    return (msg?.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim() || null;
  }
  return null;
}

export async function askAI(cfg, messages, { vision = false, forceSearch = false } = {}) {
  const errors = [];
  const searchOn = Boolean(cfg.search && cfg.keys.tavily && !vision);
  // pehle (zaroorat ho to) lazmi search, phir normal search, aakhir mein bina search
  const attempts = !searchOn
    ? [{ search: false }]
    : forceSearch
      ? [{ search: true, force: true }, { search: true, force: false }, { search: false }]
      : [{ search: true, force: false }, { search: false }];

  for (const p of cfg.order) {
    const key = cfg.keys[p];
    const model = cfg.models[p]?.[vision ? 'vision' : 'text'];
    if (!key || !model || !ENDPOINTS[p]) continue;
    for (const attempt of attempts) {
      const sources = [];
      try {
        const text = await run(cfg, p, key, model, messages, attempt, sources);
        if (text) return { text, provider: p, model, sources: [...new Set(sources)].slice(0, 3) };
        errors.push(`${p}: khali jawab`);
        break;
      } catch (e) {
        errors.push(`${p}: ${e.message}`);
        // is model par tools/required support nahi - isi provider par agla tareeqa
        if (attempt.search && [400, 404, 422].includes(e.status)) continue;
        break;
      }
    }
  }
  throw new Error(errors.length ? errors.join(' | ') : 'Koi API key set nahi hai. Use: !setkey groq <key>');
}

// ---------- !test command: har key/model ka live check ----------
function crc32(buf) {
  let crc = 0xffffffff;
  for (const b of buf) {
    crc ^= b;
    for (let k = 0; k < 8; k++) crc = crc & 1 ? (crc >>> 1) ^ 0xedb88320 : crc >>> 1;
  }
  return (crc ^ 0xffffffff) >>> 0;
}

// Chhoti laal (red) PNG - vision test ke liye
function redPng(size = 64) {
  const row = Buffer.alloc(1 + size * 3);
  for (let x = 0; x < size; x++) {
    row[1 + x * 3] = 220;
    row[2 + x * 3] = 20;
    row[3 + x * 3] = 20;
  }
  const raw = Buffer.concat(Array.from({ length: size }, () => row));
  const chunk = (type, data) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(td));
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 2; // RGB
  const png = Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ]);
  return 'data:image/png;base64,' + png.toString('base64');
}

// kind: 'text' | 'vision' | 'tools'. Ek line deta hai: ✅ ... ya ❌ ...
export async function probe(cfg, p, kind) {
  const key = cfg.keys[p];
  if (!key) return '❌ key nahi';
  const model = cfg.models[p]?.[kind === 'vision' ? 'vision' : 'text'];
  const t0 = Date.now();
  try {
    const messages =
      kind === 'vision'
        ? [{ role: 'user', content: [{ type: 'text', text: 'Is image ka main rang sirf ek lafz mein batao.' }, { type: 'image_url', image_url: { url: redPng() } }] }]
        : [{ role: 'user', content: 'Sirf ek lafz mein jawab do: OK' }];
    const msg = await chat(p, key, model, messages, kind === 'tools' ? [SEARCH_TOOL] : undefined, 'auto', 400);
    const secs = ((Date.now() - t0) / 1000).toFixed(1);
    const reply =
      (msg?.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').replace(/\s+/g, ' ').trim().slice(0, 30) ||
      (msg?.tool_calls?.length ? '(tool call)' : '(jawab khali, lekin connected)');
    return `✅ ${secs}s "${reply}"`;
  } catch (e) {
    return `❌ ${e.message.slice(0, 110)}`;
  }
}
