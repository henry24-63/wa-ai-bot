// Groq, OpenRouter aur Google AI Studio - teeno OpenAI-compatible endpoint use karte hain.
// Order mein try karta hai; ek fail ho (limit, error, timeout) to agla.
const ENDPOINTS = {
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions',
  google: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
};

export async function askAI(cfg, messages, { vision = false } = {}) {
  const errors = [];
  for (const p of cfg.order) {
    const key = cfg.keys[p];
    const model = cfg.models[p]?.[vision ? 'vision' : 'text'];
    if (!key || !model || !ENDPOINTS[p]) continue;
    try {
      const res = await fetch(ENDPOINTS[p], {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
        body: JSON.stringify({ model, messages, temperature: 0.6, max_tokens: 1500 }),
        signal: AbortSignal.timeout(60000),
      });
      if (!res.ok) {
        errors.push(`${p}: HTTP ${res.status} ${(await res.text()).slice(0, 120)}`);
        continue;
      }
      const data = await res.json();
      const text = data.choices?.[0]?.message?.content?.trim();
      if (text) return { text, provider: p, model };
      errors.push(`${p}: khali jawab`);
    } catch (e) {
      errors.push(`${p}: ${e.message}`);
    }
  }
  throw new Error(errors.length ? errors.join(' | ') : 'Koi API key set nahi hai. Use: !setkey groq <key>');
}
