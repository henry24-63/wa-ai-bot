import pdf from 'pdf-parse/lib/pdf-parse.js';
import mammoth from 'mammoth';
import JSZip from 'jszip';

const decode = (s) =>
  s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&amp;/g, '&');

// PowerPoint (.pptx): har slide ka text nikalta hai (slide ki images nahi padhi jati).
async function pptxText(buffer) {
  const zip = await JSZip.loadAsync(buffer);
  const num = (f) => Number(f.match(/slide(\d+)\.xml$/)[1]);
  const files = Object.keys(zip.files)
    .filter((f) => /^ppt\/slides\/slide\d+\.xml$/.test(f))
    .sort((a, b) => num(a) - num(b));
  const out = [];
  for (const [i, f] of files.entries()) {
    const xml = await zip.file(f).async('string');
    const paras = xml
      .split('</a:p>')
      .map((p) => [...p.matchAll(/<a:t>([^<]*)<\/a:t>/g)].map((m) => decode(m[1])).join(''))
      .map((t) => t.trim())
      .filter(Boolean);
    if (paras.length) out.push(`--- Slide ${i + 1} ---\n${paras.join('\n')}`);
  }
  return out.join('\n\n');
}

// Document se text nikalta hai. Unsupported type par null deta hai.
export async function extractText(buffer, mime = '', name = '') {
  const n = name.toLowerCase();
  if (mime === 'application/pdf' || n.endsWith('.pdf')) {
    const r = await pdf(buffer);
    return r.text;
  }
  if (n.endsWith('.docx') || mime.includes('wordprocessingml')) {
    const r = await mammoth.extractRawText({ buffer });
    return r.value;
  }
  if (n.endsWith('.pptx') || mime.includes('presentationml.presentation')) return pptxText(buffer);
  if (mime.startsWith('text/') || /\.(txt|md|csv|json)$/.test(n)) return buffer.toString('utf8');
  return null;
}
