import pdf from 'pdf-parse/lib/pdf-parse.js';
import mammoth from 'mammoth';

// Document se text nikalta hai. Unsupported type par null deta hai.
export async function extractText(buffer, mime = '', name = '') {
  const n = name.toLowerCase();
  if (mime === 'application/pdf' || n.endsWith('.pdf')) {
    const r = await pdf(buffer);
    return r.text;
  }
  if (n.endsWith('.docx') || mime.includes('wordprocessingml')) {
    const r = await mammoth.extractRawText({ buffer });
    return r.value;
  }
  if (mime.startsWith('text/') || /\.(txt|md|csv|json)$/.test(n)) return buffer.toString('utf8');
  return null;
}
