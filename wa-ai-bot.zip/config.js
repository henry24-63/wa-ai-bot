import fs from 'fs';

const DIR = 'data';
const FILE = `${DIR}/config.json`;

export const PROVIDERS = ['groq', 'openrouter', 'google'];

const defaults = {
  enabled: true,
  search: true, // web search (Tavily key ho tabhi chalta hai)
  allowed: [], // sirf in numbers ko reply milega
  order: ['groq', 'openrouter', 'google'],
  keys: { groq: '', openrouter: '', google: '', tavily: '' },
  models: {
    groq: { text: 'openai/gpt-oss-120b', vision: 'meta-llama/llama-4-scout-17b-16e-instruct' },
    openrouter: { text: 'meta-llama/llama-3.3-70b-instruct:free', vision: 'google/gemma-3-27b-it:free' },
    google: { text: 'gemini-2.5-flash', vision: 'gemini-2.5-flash' },
  },
  // zaban aur formatting ke rules index.js ke RULES mein hain
  prompt:
    'Tum ek friendly study assistant ho jo WhatsApp par chat kar raha hai. ' +
    'Jawab chhote, saaf aur seedhe rakho, zarurat ho to steps mein samjhao. ' +
    'Agar document diya gaya ho to uski basis par jawab do aur guess mat karo.',
};

// Purana default prompt (jo config.json mein save ho chuka ho) - naye se badal diya jata hai
const OLD_PROMPT =
  'Tum ek friendly study assistant ho jo WhatsApp par chat kar raha hai. ' +
  'User jis language mein likhe (Urdu, Roman Urdu, English) usi mein jawab do. ' +
  'Jawab chhote, saaf aur seedhe rakho, zarurat ho to steps mein samjhao. ' +
  'Agar document diya gaya ho to uski basis par jawab do aur guess mat karo.';

export function loadConfig() {
  fs.mkdirSync(DIR, { recursive: true });
  let saved = {};
  try {
    saved = JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {}
  const cfg = { ...defaults, ...saved };
  if (saved.prompt === OLD_PROMPT) cfg.prompt = defaults.prompt;
  cfg.keys = { ...defaults.keys, ...(saved.keys || {}) };
  cfg.models = {};
  for (const p of PROVIDERS) cfg.models[p] = { ...defaults.models[p], ...(saved.models?.[p] || {}) };
  return cfg;
}

export function saveConfig(cfg) {
  fs.mkdirSync(DIR, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(cfg, null, 2), { mode: 0o600 });
}
