import fs from 'fs';

const DIR = 'data';
const FILE = `${DIR}/config.json`;

export const PROVIDERS = ['groq', 'openrouter', 'google'];

const defaults = {
  enabled: true,
  allowed: [], // sirf in numbers ko reply milega
  order: ['groq', 'openrouter', 'google'],
  keys: { groq: '', openrouter: '', google: '' },
  models: {
    groq: { text: 'llama-3.3-70b-versatile', vision: 'meta-llama/llama-4-scout-17b-16e-instruct' },
    openrouter: { text: 'meta-llama/llama-3.3-70b-instruct:free', vision: 'google/gemma-3-27b-it:free' },
    google: { text: 'gemini-2.5-flash', vision: 'gemini-2.5-flash' },
  },
  prompt:
    'Tum ek friendly study assistant ho jo WhatsApp par chat kar raha hai. ' +
    'User jis language mein likhe (Urdu, Roman Urdu, English) usi mein jawab do. ' +
    'Jawab chhote, saaf aur seedhe rakho, zarurat ho to steps mein samjhao. ' +
    'Agar document diya gaya ho to uski basis par jawab do aur guess mat karo.',
};

export function loadConfig() {
  fs.mkdirSync(DIR, { recursive: true });
  let saved = {};
  try {
    saved = JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {}
  const cfg = { ...defaults, ...saved };
  cfg.keys = { ...defaults.keys, ...(saved.keys || {}) };
  cfg.models = {};
  for (const p of PROVIDERS) cfg.models[p] = { ...defaults.models[p], ...(saved.models?.[p] || {}) };
  return cfg;
}

export function saveConfig(cfg) {
  fs.mkdirSync(DIR, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(cfg, null, 2), { mode: 0o600 });
}
