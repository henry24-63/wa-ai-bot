import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  downloadMediaMessage,
  fetchLatestBaileysVersion,
  Browsers,
} from '@whiskeysockets/baileys';
import pino from 'pino';
import qrcode from 'qrcode-terminal';
import { loadConfig, saveConfig, PROVIDERS } from './config.js';
import { askAI } from './ai.js';
import { extractText } from './docs.js';

const logger = pino({ level: 'silent' });
let cfg = loadConfig();

const sessions = new Map(); // jid -> { history: [], doc: {name,text} | null }
const sentIds = new Set(); // bot ke apne bheje hue message ids (loop se bachne ke liye)
const blocked = new Map(); // allow-list mein na hone wale senders (!pending ke liye)
const BOT_PREFIX = '🤖 ';

const digits = (s) => (s || '').split('@')[0].split(':')[0].replace(/\D/g, '');
const chunks = (t, n) => {
  const out = [];
  for (let i = 0; i < t.length; i += n) out.push(t.slice(i, i + n));
  return out;
};
const session = (jid) => {
  if (!sessions.has(jid)) sessions.set(jid, { history: [], doc: null });
  return sessions.get(jid);
};
const mask = (k) => (k ? `${k.slice(0, 4)}…${k.slice(-3)}` : '—');

function isSelfJid(sock, jid) {
  const mine = [digits(sock.user?.id), digits(sock.user?.lid)].filter(Boolean);
  return mine.includes(digits(jid));
}

async function reply(sock, jid, text) {
  const pre = isSelfJid(sock, jid) ? BOT_PREFIX : '';
  for (const c of chunks(text, 3500)) {
    const r = await sock.sendMessage(jid, { text: pre + c });
    if (r?.key?.id) {
      sentIds.add(r.key.id);
      if (sentIds.size > 500) sentIds.delete(sentIds.values().next().value);
    }
  }
}

const HELP = `*Owner commands* (apne hi "Message yourself" chat mein)
!status - sab settings
!setkey <groq|openrouter|google> <key>
!delkey <provider>
!setmodel <provider> <text|vision> <model>
!order groq,openrouter,google
!allow <number> - e.g. !allow 923001234567
!disallow <number>
!list - allowed numbers
!pending - jin numbers ne msg kiya par allowed nahi
!prompt <text> - bot ki personality/instructions
!clear - is chat ki history aur document saaf
!on / !off - bot chalao ya roko`;

async function command(sock, m, jid, text) {
  const [cmd, ...args] = text.trim().split(/\s+/);
  const say = (t) => reply(sock, jid, t);
  switch (cmd.toLowerCase()) {
    case '!help':
      return say(HELP);

    case '!status':
      return say(
        `Bot: ${cfg.enabled ? 'ON' : 'OFF'}\nOrder: ${cfg.order.join(' → ')}\n` +
          PROVIDERS.map((p) => `${p}: ${cfg.keys[p] ? '✅ ' + mask(cfg.keys[p]) : '❌ key nahi'} | ${cfg.models[p].text} | vision: ${cfg.models[p].vision}`).join('\n') +
          `\nAllowed numbers: ${cfg.allowed.length}`
      );

    case '!setkey': {
      const [p, key] = [args[0]?.toLowerCase(), args[1]];
      if (!PROVIDERS.includes(p) || !key) return say('Use: !setkey groq <key>\nProviders: groq, openrouter, google');
      cfg.keys[p] = key;
      saveConfig(cfg);
      try {
        await sock.sendMessage(jid, { delete: m.key }); // key wala message delete
      } catch {}
      return say(`✅ ${p} key save ho gayi (${mask(key)}). Aap ka key wala message delete karne ki koshish ki hai.`);
    }

    case '!delkey': {
      const p = args[0]?.toLowerCase();
      if (!PROVIDERS.includes(p)) return say('Use: !delkey groq');
      cfg.keys[p] = '';
      saveConfig(cfg);
      return say(`🗑️ ${p} key hata di.`);
    }

    case '!setmodel': {
      const [p, kind, ...rest] = args;
      const model = rest.join(' ');
      if (!PROVIDERS.includes(p?.toLowerCase()) || !['text', 'vision'].includes(kind) || !model)
        return say('Use: !setmodel groq text llama-3.3-70b-versatile');
      cfg.models[p.toLowerCase()][kind] = model;
      saveConfig(cfg);
      return say(`✅ ${p} ${kind} model: ${model}`);
    }

    case '!order': {
      const list = (args.join('').toLowerCase().split(',').filter(Boolean));
      if (!list.length || !list.every((p) => PROVIDERS.includes(p))) return say('Use: !order groq,openrouter,google');
      cfg.order = [...new Set(list)];
      saveConfig(cfg);
      return say(`✅ Order: ${cfg.order.join(' → ')}`);
    }

    case '!allow': {
      const n = digits(args[0]);
      if (!n) return say('Use: !allow 923001234567');
      if (!cfg.allowed.includes(n)) cfg.allowed.push(n);
      saveConfig(cfg);
      return say(`✅ ${n} allowed. Ab is number ke messages ka AI jawab dega.`);
    }

    case '!disallow': {
      const n = digits(args[0]);
      cfg.allowed = cfg.allowed.filter((x) => x !== n);
      saveConfig(cfg);
      return say(`🚫 ${n} hata diya.`);
    }

    case '!list':
      return say(cfg.allowed.length ? 'Allowed:\n' + cfg.allowed.join('\n') : 'Koi number allowed nahi. Use: !allow <number>');

    case '!pending':
      return say(
        blocked.size
          ? 'In ne msg kiya (allowed nahi):\n' + [...blocked].map(([id, name]) => `${id} ${name ? '(' + name + ')' : ''}`).join('\n') + '\n\nAllow karne ke liye: !allow <id>'
          : 'Koi pending nahi.'
      );

    case '!prompt': {
      const p = args.join(' ');
      if (!p) return say(`Current prompt:\n${cfg.prompt}`);
      cfg.prompt = p;
      saveConfig(cfg);
      return say('✅ Prompt update ho gaya.');
    }

    case '!clear':
      sessions.delete(jid);
      return say('🧹 History aur document saaf.');

    case '!on':
    case '!off':
      cfg.enabled = cmd.toLowerCase() === '!on';
      saveConfig(cfg);
      return say(`Bot ${cfg.enabled ? 'ON' : 'OFF'}`);

    default:
      return say('Ye command nahi mili. !help likho.');
  }
}

async function handle(sock, m) {
  if (!m.message || m.key.remoteJid === 'status@broadcast') return;
  const jid = m.key.remoteJid;
  if (/@(g\.us|broadcast|newsletter)$/.test(jid)) return; // groups ignore
  if (sentIds.has(m.key.id)) return;

  const self = isSelfJid(sock, jid);
  if (m.key.fromMe && !self) return; // aap ne kisi aur ko khud msg kiya - ignore

  const inner = m.message.ephemeralMessage?.message || m.message.viewOnceMessage?.message || m.message;
  const text = inner.conversation || inner.extendedTextMessage?.text || inner.imageMessage?.caption || inner.documentMessage?.caption || '';
  if (m.key.fromMe && text.startsWith(BOT_PREFIX)) return;

  // owner = apni self-chat; baaki sirf allow-list
  const ids = [jid, m.key.senderPn, m.key.remoteJidAlt, m.key.participantPn].map(digits).filter(Boolean);
  const allowed = self || ids.some((i) => cfg.allowed.includes(i));
  if (!allowed) {
    blocked.set(ids[0], m.pushName || '');
    if (blocked.size > 10) blocked.delete(blocked.keys().next().value);
    console.log('Blocked sender:', ids.join(','), m.pushName || '');
    return;
  }
  if (!cfg.enabled && !self) return;

  if (self && text.startsWith('!')) return command(sock, m, jid, text);

  const s = session(jid);
  await sock.sendPresenceUpdate('composing', jid);

  try {
    let question = text.trim();
    let messages;
    let vision = false;
    let historyNote = question;

    if (inner.imageMessage) {
      const buf = await downloadMediaMessage(m, 'buffer', {}, { logger, reuploadRequest: sock.updateMediaMessage });
      const mime = inner.imageMessage.mimetype || 'image/jpeg';
      question = question || 'Is image mein jo likha ya dikhaya gaya hai wo scan karke samjha do.';
      historyNote = `[image bheji] ${question}`;
      vision = true;
      messages = buildMessages(s, [
        { type: 'text', text: question },
        { type: 'image_url', image_url: { url: `data:${mime};base64,${buf.toString('base64')}` } },
      ]);
    } else if (inner.documentMessage) {
      const buf = await downloadMediaMessage(m, 'buffer', {}, { logger, reuploadRequest: sock.updateMediaMessage });
      const name = inner.documentMessage.fileName || 'document';
      const t = await extractText(buf, inner.documentMessage.mimetype || '', name);
      if (t === null) return reply(sock, jid, 'Ye file type support nahi: PDF, DOCX, TXT/MD/CSV bhejo, ya page ki photo bhej do.');
      if (t.trim().length < 30) return reply(sock, jid, 'Is file mein text nahi mila (scanned lagti hai). Pages ki photos bhej do, main scan kar lunga.');
      s.doc = { name, text: t.slice(0, 15000) };
      question = question || 'Is document ka short summary aur key points bata do.';
      historyNote = `[document "${name}" bheja] ${question}`;
      messages = buildMessages(s, question);
    } else if (question) {
      messages = buildMessages(s, question);
    } else {
      return; // voice/sticker etc.
    }

    const { text: answer } = await askAI(cfg, messages, { vision });
    s.history.push({ role: 'user', content: historyNote }, { role: 'assistant', content: answer });
    s.history = s.history.slice(-12);
    await reply(sock, jid, answer);
  } catch (e) {
    console.error('AI error:', e.message);
    await reply(sock, jid, self ? `⚠️ ${e.message}` : 'Abhi jawab nahi de sakta, thori der baad try karein.');
  } finally {
    await sock.sendPresenceUpdate('paused', jid);
  }
}

function buildMessages(s, userContent) {
  const sys = cfg.prompt + (s.doc ? `\n\nUser ka loaded document "${s.doc.name}":\n"""\n${s.doc.text}\n"""` : '');
  return [{ role: 'system', content: sys }, ...s.history, { role: 'user', content: userContent }];
}

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('data/auth');
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version,
    auth: state,
    logger,
    browser: Browsers.ubuntu('Chrome'),
    syncFullHistory: false,
    markOnlineOnConnect: false,
  });

  sock.ev.on('creds.update', saveCreds);

  // QR ke bajaye phone number se pairing code: PAIR_PHONE=923001234567 node index.js
  if (!state.creds.registered && process.env.PAIR_PHONE) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(process.env.PAIR_PHONE.replace(/\D/g, ''));
        console.log('\n=== PAIRING CODE:', code, '===\nWhatsApp > Linked devices > Link with phone number\n');
      } catch (e) {
        console.error('Pairing code error:', e.message);
      }
    }, 3000);
  }

  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr && !process.env.PAIR_PHONE) {
      qrcode.generate(qr, { small: true });
      console.log('QR scan karo: WhatsApp > Linked devices > Link a device');
    }
    if (connection === 'open') console.log('✅ Connected as', sock.user?.id);
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code === DisconnectReason.loggedOut) {
        console.log('Logged out. data/auth folder delete karo aur dobara chalao.');
        process.exit(1);
      }
      setTimeout(start, 3000);
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) {
      try {
        await handle(sock, m);
      } catch (e) {
        console.error('handle error:', e.message);
      }
    }
  });
}

start();
